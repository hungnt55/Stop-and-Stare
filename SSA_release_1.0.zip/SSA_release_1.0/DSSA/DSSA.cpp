#include "option.h"
#include "hypergraph.hpp"
#include "sfmt/SFMT.h"
#include <iostream>
#include <ctime>
#include <cmath>

using namespace std;

bool calculateInfluence(HyperGraph & hg, Graph & g, vector<int> & seeds, int t, double & deg, float epsilon, float delta, int m, long long int& maxSamples){
	long long  counter = 0;
	int n = g.getSize();
	unsigned k = seeds.size();
	vector<unsigned int> link(n + 1, seeds.size());
	double degree=0;
	for (unsigned int i = 0; i < k;++i){
		link[seeds[i]] = i;
	}
	vector<bool> maxSeed(t, false);

	bool ch=false;
	omp_set_num_threads(t);
	#pragma omp parallel
	{
		vector<bool> visit(n+1,false);
		vector<int> visit_mark(n,0);
		int id = omp_get_thread_num();

		if (m == 0){
			while(counter < maxSamples){
        		       	maxSeed[id]=hg.pollingLT2(g,link,k,visit,visit_mark);
				#pragma omp critical
				{
					counter += 1;
					if (maxSeed[id]){
						degree++;
					}
				}
               	        }
		} else {
			while(counter < maxSamples){
				maxSeed[id]=hg.pollingIC2(g,link,k,visit,visit_mark);
                                #pragma omp critical
                                {
					counter += 1;
                                        if (maxSeed[id]){
                                                degree++;
                                        }
                                }
                        }
                }
	}
	double epsilon_1 = (deg*n/maxSamples)/(degree*n/counter) - 1;
        if (epsilon_1 < epsilon){
		double f = (log(2/delta)+lgamma(n+1)-lgamma(k+1)-lgamma(n-k+1))/(k*log(2/delta));
		if (f < 1)
			f = 1;
                double epsilon_2 = sqrt(log(f))*(epsilon-epsilon_1)/(2*(1+epsilon_1));
                double epsilon_3 = (1-sqrt(log(f))/2)*(epsilon-epsilon_1)/((1-1/exp(1)));
                double delta_1 = exp(-(deg*epsilon_3*epsilon_3)/((2+2*epsilon_2/3)*(1+epsilon_1)*(1+epsilon_2)));
                double delta_2 = exp(-(degree*epsilon_2*epsilon_2)/((2+2*epsilon_2/3)*(1+epsilon_2)))*log(f);
                if (delta_1+delta_2 <= delta){
                         ch = true;
                }
        }

	hg.updateDeg();
	return ch;
}

int main(int argc, char ** argv)
{
	srand(time(NULL));

	OptionParser op(argc, argv);
	if (!op.validCheck()){
		printf("Parameters error, please check the readme.txt file for correct format!\n");
		return -1;
	}
	char * inFile = op.getPara("-i");
	if (inFile == NULL){
		inFile = (char*)"network.bin";
	}

	char * outFile = op.getPara("-o");
	if (outFile == NULL){
		outFile = (char*)"network.seeds";
	}

        char * model = op.getPara("-m");
        if (model == NULL)
                model = (char *) "LT";

	Graph g;
	if (strcmp(model, "LT") == 0){
		g.readGraphLT(inFile);
	} else if (strcmp(model, "IC") == 0){
		g.readGraphIC(inFile);
	} else {
		printf("Incorrect model option!");
		return -1;
	}

	int n = g.getSize();

	char * tmp = op.getPara("-epsilon");
	float epsilon = 0.1;
	if (tmp != NULL){
		epsilon = atof(tmp);
	}

	float delta = 1.0/n;
	tmp = op.getPara("-delta");
        if (tmp != NULL){
                delta = atof(tmp);
        }

	float k = n;
	
	tmp = op.getPara("-k");
	if (tmp != NULL){
		k = atof(tmp);
	}	

	int t = 1;
	tmp = op.getPara("-t");
	if (tmp != NULL){
		t = atoi(tmp);
	}
	
	HyperGraph hg(n);
	vector<double> degree(k+1,0);

	vector<int> seeds;

	long long int totalSamples = (8+2*epsilon)*(1+epsilon)*(1+epsilon)*log(2/delta)/(epsilon*epsilon);

	int mo = 0;
	if (strcmp(model, "IC") == 0)
		mo = 1;

	addHyperedge(g,hg,t,totalSamples,mo);
	
	clock_t start = clock();

	while (true){
		seeds.clear();
		totalSamples = hg.getNumEdge();
		buildSeedSet(hg,seeds,n,k,degree);
		if (calculateInfluence(hg,g,seeds,t,degree[k],epsilon,delta,mo,totalSamples)){
                       	break;
                }
	}
	cout << "Seed Nodes: ";
	ofstream out(outFile);
	for (unsigned int i = 0; i < seeds.size(); ++i){
		cout << seeds[i] << " ";
		out << seeds[i] << endl;
	}
	out.close();
	cout << endl << endl;
 	printf("Influence: %0.2lf\n",(double)degree[k]*n/totalSamples);
	cout << "Time: " << (float)(clock()-start)/CLOCKS_PER_SEC << "s" << endl;
	cout << "Memory: " << getCurrentMemoryUsage() << " MB" << endl;
}
